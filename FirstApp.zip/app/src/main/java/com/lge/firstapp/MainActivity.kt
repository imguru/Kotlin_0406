package com.lge.firstapp

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.commit

import kotlinx.android.synthetic.main.activity_main2.*
import kotlinx.android.synthetic.main.activity_second.nameTextView as textView

// 코틀린 기반 안드로이드 프로젝트의 설정
// 1. project 수준의 build.gradle
// classpath "org.jetbrains.kotlin:kotlin-gradle-plugin:$kotlin_version"

// 2. app 수준의 build.gradle
// apply plugin: 'kotlin-android'
// apply plugin: 'kotlin-android-extensions'

// 3. app 수준의 build.gradle 의존성 부분
// implementation "org.jetbrains.kotlin:kotlin-stdlib-jdk7:$kotlin_version"

// 4. app 수준의 build.gradle에서 android 영역에 JAVA8 설정 '추가'
/*
compileOptions {
    sourceCompatibility JavaVersion.VERSION_1_8
    targetCompatibility JavaVersion.VERSION_1_8
}

kotlinOptions {
    jvmTarget = "1.8"
}
*/
// 5. app 수준의 build.gradle에서 kotlin의 디렉토리를
//    추가
/*
sourceSets {
    main.java.srcDirs += "src/main/kotlin"
}
*/

fun Context.toast(message: String): Unit {
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}

fun Context.toastLong(message: String): Unit {
    Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}

inline fun <reified T> Context.startActivity() {
    val intent = Intent(this, T::class.java)
    startActivity(intent)
}


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)


        // findViewById
        /* Java */
        // val nameTextView = (TextView)findViewById(R.id.nameTextView)
        /*
        val nameTextView = findViewById<TextView>(R.id.nameTextView)
        val nameButton = findViewById<Button>(R.id.nameButton)

        nameButton.setOnClickListener(object: View.OnClickListener {
            override fun onClick(v: View?) {
                nameTextView.text = "Hi!"
            }
        })
        */

        // Kotlin에서는 findViewById가 필요없습니다.
        // kotlin-android-extensions
        // android:id="@+id/nameTextView"
        // 이름 규칙
        //    1. nameTextView     - 코틀린 추천
        //    2. name_text_view
        //    3. tv_name

        // View.OnClickListener - SAM(Single Abstract Method) 지원 문법
        /*
        nameButton.setOnClickListener {
            nameTextView.text = "hello!"
            val intent = Intent(
                this,
                SecondActivity::class.java
            )  // Class<?>
            startActivity(intent)
        }
        */

        // Fragment 추가하는 코드
        val fragment = MainFragment()
        fragment.name = "Tom"

        // 1. Extension Function
        // 2. T.() -> Unit
        supportFragmentManager.commit {
            add(R.id.mainFrame, fragment)
        }

        // Anko(Android Kotlin) - Jetbrains 라이브러리
        // => Deprecated 이므로, 사용하면 안됩니다.

        // 1. Toast
        // Toast.makeText(this, "xxx", Toast.LENGTH_SHORT).show()
        toast("xxx")

        // 2. startActivity
        startActivity<SecondActivity>()

        /*
        supportFragmentManager.beginTransaction()
            .add(R.id.mainFrame, fragment)
            .commit()

        */


        /*
        nameButton.setOnClickListener(object: View.OnClickListener {
            override fun onClick(v: View?) {
                val intent = Intent(this@MainActivity,
                        SecondActivity::class.java)
                startActivity(intent)
            }
        })
        */
        // 주의 사항
        // import kotlinx.android.synthetic.main.activity_main.*
        // Inflating 한 View와 동일한지 확인해야 합니다.
        // - setContentView(R.layout.activity_main)
    }
}

// AndroidManimest.xml
//         <activity android:name=".SecondActivity" />
class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        textView.text = ""
    }
}

// AndroidManifest.xml에 추가할 필요가 없다.

// App을 만들 때, Activity는 한개만 존재하는 것이 권장 사항입니다.
class MainFragment : Fragment() {
    var name: String = ""

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? = inflater.inflate(
        R.layout.fragment_main, container, false
    )

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
    }
}





